## Morgan Ntare
## Intro to Programming 2 homework
## 03/03/2025

def text_analysis(file_path):  # Corrected formal parameter name
    try:
        with open(file_path, 'r') as file:  # Use the parameter instead of a fixed filename
            text = file.read()

            num_sentences = text.count('.') + text.count('!') + text.count('?')
            num_words = len(text.split())
            avg_words_per_sentence = num_words / num_sentences if num_sentences > 0 else 0
            num_uppercase = sum(1 for char in text if char.isupper())  # Fixed +1 to 1
            num_lowercase = sum(1 for char in text if char.islower())
            num_digits = sum(1 for char in text if char.isdigit())
            num_whitespaces = text.count(' ')

            print(f"Sentences: {num_sentences}")
            print(f"Words: {num_words}")
            print(f"Avg Words per Sentence: {avg_words_per_sentence:.2f}")
            print(f"Uppercase Letters: {num_uppercase}")
            print(f"Lowercase Letters: {num_lowercase}")
            print(f"Digits: {num_digits}")
            print(f"White Spaces: {num_whitespaces}")

    except FileNotFoundError:
        print("Error: File not found.")
    except Exception as e:
        print(f"Error: {e}")

# Calling the function with the correct argument
text_analysis("text.txt")
