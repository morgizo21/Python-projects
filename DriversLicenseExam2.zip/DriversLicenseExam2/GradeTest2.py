# GradeTest2.py
# Name: Morgan Ntare
# Course: IT 262 – Introduction to Computer Programming 2
# Assignment: HMWK 08 – Driver’s License Exam 2
# Description: This program grades a driver's license exam using dictionaries and a text file.

# Step 1: List of correct answers
correct_answers = ["A", "C", "A", "A", "D", "B", "C", "A", "C", "B",
                   "A", "D", "C", "A", "D", "C", "B", "B", "D", "A"]

# Step 2: Create empty dictionaries
student_responses = {}  # Will store name and their list of answers
student_grades = {}     # Will store name and their grade info

# Step 3: Read data from StudentResponses.txt file
with open("StudentResponses.txt", "r") as file:
    for line in file:
        line = line.strip()              # Remove any extra spaces or newline
        parts = line.split(",")          # Split the line by commas
        name = parts[0]                  # First part is the student name
        answers = parts[1:]              # Rest are the answers
        student_responses[name] = answers  # Store in dictionary

# Step 4: Grade each student
for name in student_responses:
    answers = student_responses[name]
    correct = 0
    incorrect = 0
    wrong_questions = []

    # Compare answers to correct ones
    for i in range(20):
        if answers[i] == correct_answers[i]:
            correct += 1
        else:
            incorrect += 1
            wrong_questions.append(i + 1)  # Add 1 to make question number start from 1

    # Check if student passed
    if correct >= 15:
        result = "PASS"
    else:
        result = "FAIL"

    # Store results in second dictionary
    student_grades[name] = {
        "Correct": correct,
        "Incorrect": incorrect,
        "Wrong Questions": wrong_questions,
        "Result": result
    }

# Step 5: Print results
print("\n--- Student Results ---")
for name in student_grades:
    print("\nStudent:", name)
    print("Correct Answers:", student_grades[name]["Correct"])
    print("Incorrect Answers:", student_grades[name]["Incorrect"])
    print("Questions Missed:", student_grades[name]["Wrong Questions"])
    print("Result:", student_grades[name]["Result"])
