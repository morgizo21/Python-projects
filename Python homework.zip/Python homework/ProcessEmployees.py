# ProcessEmployees.py
from EmployeeClass import *

employeeDict = {}
prodWorkerDict = {}
shiftSuperDict = {}

def createEmployeeObj(empDataString):
    empData = empDataString.strip().split(',')

    emp_number = int(empData[0])
    name = empData[1]
    job_code = empData[2]

    if job_code == "PW":
        obj = ProdWorker(emp_number, name)
        obj.setJobCode(job_code)
        obj.setShiftNbr(int(empData[3]))
        obj.setRateOfPay(float(empData[4]))
    elif job_code == "SS":
        obj = ShiftSupervisor(emp_number, name)
        obj.setJobCode(job_code)
        obj.setSalary(float(empData[3]))
        obj.setBonus(float(empData[4]))
    else:
        obj = Employee(emp_number, name)
        obj.setJobCode(job_code)

    return obj

def addEmpToDictionary(empObject):
    employeeDict[empObject.getNumber()] = empObject
    if isinstance(empObject, ProdWorker):
        prodWorkerDict[empObject.getNumber()] = empObject
    elif isinstance(empObject, ShiftSupervisor):
        shiftSuperDict[empObject.getNumber()] = empObject
    else:
        print(f"Unknown job code for employee #{empObject.getNumber()}: {empObject.getJobCode()}")

def main():
    with open("EmployeeData.txt", "r") as file:
        for line in file:
            empObj = createEmployeeObj(line)
            addEmpToDictionary(empObj)

    print("\n--- Unknown Job Codes ---")
    for emp in employeeDict.values():
        if emp.getJobCode() not in ["PW", "SS"]:
            print(emp)

    print("\n--- Production Workers ---")
    for emp in prodWorkerDict.values():
        print(emp)

    print("\n--- Shift Supervisors ---")
    for emp in shiftSuperDict.values():
        print(emp)

    print("\n--- All Employees ---")
    for emp in employeeDict.values():
        print(emp)

main()
