# EmployeeClass.py

class Employee:
    def __init__(self, emp_number, name):
        self.__emp_number = emp_number
        self.__name = name
        self.__job_code = ""

    def setName(self, name):
        self.__name = name

    def setNumber(self, number):
        self.__emp_number = number

    def setJobCode(self, job_code):
        self.__job_code = job_code

    def getName(self):
        return self.__name

    def getNumber(self):
        return self.__emp_number

    def getJobCode(self):
        return self.__job_code

    def __str__(self):
        return f"{self.__emp_number} | {self.__name} | {self.__job_code}"


class ProdWorker(Employee):
    def __init__(self, emp_number, name):
        super().__init__(emp_number, name)
        self.__shift = 0
        self.__rate = 0.0

    def setShiftNbr(self, shift):
        self.__shift = shift

    def setRateOfPay(self, rate):
        self.__rate = rate

    def getShiftNbr(self):
        return self.__shift

    def getRateOfPay(self):
        return self.__rate

    def __str__(self):
        return f"{super().__str__()} | Shift: {self.__shift} | Rate: ${self.__rate:.2f}"


class ShiftSupervisor(Employee):
    def __init__(self, emp_number, name):
        super().__init__(emp_number, name)
        self.__salary = 0.0
        self.__bonus = 0.0

    def setSalary(self, salary):
        self.__salary = salary

    def setBonus(self, bonus):
        self.__bonus = bonus

    def getSalary(self):
        return self.__salary

    def getBonus(self):
        return self.__bonus

    def __str__(self):
        return f"{super().__str__()} | Salary: ${self.__salary:.2f} | Bonus: ${self.__bonus:.2f}"
