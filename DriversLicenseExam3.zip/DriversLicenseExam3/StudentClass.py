## Common header.

class Student:
    def __init__(self, name):
        self.__name = name
        self.__responses = []
        self.__correct = 0
        self.__incorrect = 0
        self.__incorrect_questions = []
        self.__pass_fail = ""

    def __str__(self):
        return (
            f"Student Name: {self.__name}\n"
            f"Correct Answers: {self.__correct}\n"
            f"Incorrect Answers: {self.__incorrect}\n"
            f"Incorrect Questions: {self.__incorrect_questions}\n"
            f"Result: {self.__pass_fail}\n"
        )

    def setName(self, name):
        self.__name = name

    def setGradeList(self, responses):
        self.__responses = responses

    def getName(self):
        return self.__name

    def getGradeList(self):
        return self.__responses

    def gradeExam(self):
        correct_answers = ['A', 'C', 'A', 'A', 'D', 'B', 'C', 'A', 'C', 'B',
                           'A', 'D', 'C', 'A', 'D', 'C', 'B', 'B', 'D', 'A']

        for i in range(len(correct_answers)):
            if i < len(self.__responses):
                if self.__responses[i] == correct_answers[i]:
                    self.__correct += 1
                else:
                    self.__incorrect += 1
                    self.__incorrect_questions.append(i+1)

        if self.__correct >=15:
            self.__pass_fail = "Passed"
        else:
            self.__pass_fail = "Failed"