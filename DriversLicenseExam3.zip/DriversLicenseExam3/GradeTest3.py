## Morgan Ntare
## Intro to programming II work.
## GradeTest 3.

from StudentClass import Student  # Import the Student class

def main():
    try:
       with open("StudentResponses.txt", "r") as file:
           for line in file:
               line = line.rstrip('\n')
               parts = line.split(",")

               name = parts[0]  # Get the student's name
               answers = parts[1:]  # Get the student's answers (everything after the name)

               # create a student object
               student = Student(name)

               # Set the student's answers
               student.setGradeList(answers)

               # Grade the exam
               student.gradeExam()

               # Print the student's result
               print(student)

    except FileNotFoundError:
        print("The file 'StudentResponses.txt' was not found.")

# Run the main function
if __name__ == "__main__":
    main()